/**
 * @license Highcharts JS v10.3.1 (2022-10-31)
 * @module highcharts/modules/marker-clusters
 * @requires highcharts
 *
 * Marker clusters module for Highcharts
 *
 * (c) 2010-2021 Wojciech Chmiel
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/MarkerClusters.js';
