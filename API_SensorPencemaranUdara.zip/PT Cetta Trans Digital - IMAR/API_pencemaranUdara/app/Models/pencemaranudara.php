<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pencemaranudara extends Model
{
    use HasFactory;

    protected $table = 'pencemaranudaras';
    protected $fillable = ['kota','M25','M10'];
}
