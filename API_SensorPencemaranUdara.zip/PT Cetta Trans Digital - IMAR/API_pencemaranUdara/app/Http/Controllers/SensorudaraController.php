<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\pencemaranudara;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class SensorudaraController extends Controller
{
    public function index()
    {
        $title = 'Dasboard System';
       
        $kategori = pencemaranudara::select(DB::raw('kota'))->pluck('kota');
        $P25 = DB::table('pencemaranudaras')->pluck('M25');
        $P10 = DB::table('pencemaranudaras')->pluck('M10');
    
        return view('v_home', compact('title','kategori','P25','P10'));
    }

    public function messages()
    {
        return [
            'kota.required' => 'Kota Product harus diisi!',
            'M25.required' => 'Partikel 2,5 Micron harus diisi!',
            'M10.required' => 'Partikel 10 Micron harus diisi!',
            
        ];
    }

    public function show()
    {
        $pencemaranudaras = pencemaranudara::all();
        return response()->json($pencemaranudaras)->setStatusCode(200);
    }

    public function store(Request $req)
    {
        $validator = Validator::make($req->all(),[
            'kota' => 'required|max:100',
            'M25' => 'required|numeric',
            'M10' => 'required|numeric',
            
            ]);

        //kondisi inputan salah
        if($validator ->fails()){
            return response()->json($validator->messages())->setStatusCode(422);
        }

        //variabel sementara 
        $validated = $validator->validated();

        //inputan ke tabel product
        pencemaranudara::create([
            'kota' => $validated['kota'],
            'M25' => $validated['M25'],
            'M10' => $validated['M10'],
           
        ]);

        return response()->json('Data baru berhasil disimpan')->setStatusCode(201);
    }

    public function update(Request $req, $id)
    {
        $validator = Validator::make($req->all(),[
            'kota' => 'required|max:100',
            '25M' => 'required|numeric',
            '10M' => 'required|numeric',
            ]);

        //kondisi inputan salah
        if($validator ->fails()){
            return response()->json($validator->messages())->setStatusCode(422);
        }

         //variabel sementara 
         $validated = $validator->validated();


        $cek_id = pencemaranudara::find($id);

        if($cek_id)
        {
            pencemaranudara :: where('id', $id)
            ->update([
                'kota' => $validated['kota'],
                '25M' => $validated['25M'],
                '10M' => $validated['10M'],
            ]);
        
             return response()->json('Data baru berhasil diupdate')->setStatusCode(201);   
        }
        else
        {
            return response()->json('Data tidak ditemukan!')->setStatusCode(404);   
        }
        
       
    }

    public function cari_data($id)
    {
        $post = pencemaranudara::findOrFail($id);

        return response()->json(['data' => $post])->setStatusCode(200);
    }

    public function destroy($id)
    {
        $cek_id = pencemaranudara::find($id);

        if($cek_id)
        {
            pencemaranudara::destroy($id);

            return response()->json('Data baru berhasil dihapus')->setStatusCode(200); 
        }

        return response()->json('Data tidak ditemukan!')->setStatusCode(404); 
    }
}
