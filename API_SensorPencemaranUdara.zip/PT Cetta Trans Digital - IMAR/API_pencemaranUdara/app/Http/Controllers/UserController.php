<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Firebase\JWT\JWT;
//use Firebase\JWT\Key;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function messages()
    {
        return [
            'email.required' => 'Email harus diisi!',
            'password.required' => 'Password harus diisi!',
        ];
    }

    public function login(Request $req)
    {
        // $key = env('JWT_SECRET_KEY');
        $key = 'koderahasia';
        $validator = Validator::make($req->all(), [
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if($validator->fails())
        {
            return response()->json($validator->messages(), 422);
        }

        //mengisi inputan yang ada ditabel users
        if(Auth::attempt($validator->validated())){

            //  $key = env('JWT_SECRET_KEY');
            $key = 'koderahasia';
            
            //isian dari token
            $payload = [
                'iss' => 'http://example.org',
                'name' => Auth::User()->name,
                'role' => Auth::User()->role,
                'iat' => Carbon::now()->timestamp, // waktu ketika token di generate
                'exp' => Carbon::now()->timestamp + 60*60*2, // waktu ketika token sudah expired 2 jam
            ];

            $jwt = JWT::encode($payload, $key, 'HS256');

            return response()->json([
                'messages' => 'Token Berhasil digenerate',
                'nama' => Auth::User()->name,
                'token' => 'Bearer '.$jwt
            ], 200);
        }

        //user yg diinputkan tidak ada didalam tabel
        return response()->json(['messages' => 'Pengguna tidak ditemukan'], 422);
    }
}
