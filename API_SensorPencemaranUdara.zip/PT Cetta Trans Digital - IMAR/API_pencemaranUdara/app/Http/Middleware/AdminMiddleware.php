<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Firebase\JWT\JWT; //import
use Firebase\JWT\Key; //import

class AdminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        // $key = env('JWT_SECRET_KEY');
        $key = 'koderahasia';

        $jwt = $request->bearerToken();

        if(is_null($jwt) || $jwt == '')
        {
            return response()->json([
                'messages' => 'Anda tidak memiliki otoritas, token tidak terpenuhi'
            ], 401);
        }else{

            $decoded = JWT::decode($jwt, new Key($key, 'HS256'));

            if($decoded->role = 'admin')
            {
                return $next($request);
            }

            return response()->json([
                'messages' => 'Anda tidak memiliki otoritas, token tidak terpenuhi'
            ], 401);
        }
    }
}
